/-- LOGIN INFOS --/127.0.0.1
Identifiant : 64664646464
Password : 555555
/---------------- VICTIM DETAILS ----------------/
IP address : 127.0.0.1
Country : 
OS : Windows 10
Browser : Firefox
User agent : Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0
/-- END LOGIN INFOS --/

